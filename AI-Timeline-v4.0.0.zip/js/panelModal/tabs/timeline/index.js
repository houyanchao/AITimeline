/**
 * Timeline Settings Tab - 时间轴设置
 * 
 * 功能：
 * - 提供开关控制上下键跳转对话节点功能
 * - 按↑↓方向键快速浏览对话历史
 * - 控制各平台的箭头键导航功能
 */

class TimelineSettingsTab extends BaseTab {
    constructor() {
        super();
        this.id = 'timeline';
        this.name = chrome.i18n.getMessage('pxkmvz');
        this.icon = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <polyline points="12 6 12 12 16 14"/>
        </svg>`;
    }
    
    /**
     * 渲染设置内容
     */
    render() {
        const container = document.createElement('div');
        container.className = 'timeline-settings';
        
        // 第一部分：平台列表
        const timelinePlatforms = getPlatformsByFeature('timeline');
        const platformListTitle = `
            <div class="platform-list-title">${chrome.i18n.getMessage('mkvzpx')}</div>
            <div class="platform-list-hint">${chrome.i18n.getMessage('mzkvxp')}</div>
        `;
        
        // 生成平台列表项
        const platformItems = timelinePlatforms.map(platform => {
            const logoHtml = platform.logoPath 
                ? `<img src="${chrome.runtime.getURL(platform.logoPath)}" class="platform-logo" alt="${platform.name}">`
                : `<span class="platform-logo-placeholder">${platform.name.charAt(0)}</span>`;
            
            return `
                <div class="platform-item">
                    <div class="platform-info-left">
                        ${logoHtml}
                        <span class="platform-name">${platform.name}</span>
                    </div>
                    <label class="toggle-switch">
                        <input type="checkbox" class="platform-toggle" data-platform-id="${platform.id}">
                        <span class="toggle-slider"></span>
                    </label>
                </div>
            `;
        }).join('');
        
        // 将所有平台项包裹在统一的背景框中
        const platformSection = `
            <div class="platform-list">
                ${platformListTitle}
                <div class="platform-list-container">
                    ${platformItems}
                </div>
            </div>
        `;
        
        // 分隔线
        const divider = `<div class="divider"></div>`;
        
        // 第二部分：箭头键导航开关
        const arrowKeysSection = `
            <div class="setting-section">
                <div class="setting-item">
                    <div class="setting-info">
                        <div class="setting-label">${chrome.i18n.getMessage('vkpmzx')}</div>
                        <div class="setting-hint">
                            ${chrome.i18n.getMessage('xpvmkz')}
                        </div>
                    </div>
                    <label class="toggle-switch">
                        <input type="checkbox" id="arrow-keys-nav-toggle">
                        <span class="toggle-slider"></span>
                    </label>
                </div>
            </div>
        `;
        
        container.innerHTML = platformSection + divider + arrowKeysSection;
        
        return container;
    }
    
    /**
     * Tab 激活时加载状态
     */
    async mounted() {
        super.mounted();
        
        // 1. 处理全局箭头键导航开关
        const checkbox = document.getElementById('arrow-keys-nav-toggle');
        if (checkbox) {
            // 读取当前状态（默认开启）
            try {
                const result = await chrome.storage.local.get('arrowKeysNavigationEnabled');
                // 默认值为 true（开启）
                checkbox.checked = result.arrowKeysNavigationEnabled !== false;
            } catch (e) {
                console.error('[TimelineSettingsTab] Failed to load state:', e);
                // 读取失败，默认开启
                checkbox.checked = true;
            }
            
            // 监听开关变化
            this.addEventListener(checkbox, 'change', async (e) => {
                try {
                    const enabled = e.target.checked;
                    
                    // 保存到 Storage
                    await chrome.storage.local.set({ arrowKeysNavigationEnabled: enabled });
                } catch (e) {
                    console.error('[TimelineSettingsTab] Failed to save state:', e);
                    
                    // 保存失败，恢复checkbox状态
                    checkbox.checked = !checkbox.checked;
                }
            });
        }
        
        // 2. 处理平台开关
        await this.loadPlatformSettings();
    }
    
    /**
     * 加载并初始化平台设置
     */
    async loadPlatformSettings() {
        try {
            // 从 Storage 读取平台设置
            const result = await chrome.storage.local.get('timelinePlatformSettings');
            const platformSettings = result.timelinePlatformSettings || {};
            
            // 为每个平台开关设置状态和事件
            const platformToggles = document.querySelectorAll('.platform-toggle');
            platformToggles.forEach(toggle => {
                const platformId = toggle.getAttribute('data-platform-id');
                
                // 设置初始状态（默认开启）
                toggle.checked = platformSettings[platformId] !== false;
                
                // 监听开关变化
                this.addEventListener(toggle, 'change', async (e) => {
                    try {
                        const enabled = e.target.checked;
                        
                        // 读取当前所有设置
                        const result = await chrome.storage.local.get('timelinePlatformSettings');
                        const settings = result.timelinePlatformSettings || {};
                        
                        // 更新当前平台
                        settings[platformId] = enabled;
                        
                        // 保存到 Storage
                        await chrome.storage.local.set({ timelinePlatformSettings: settings });
                    } catch (e) {
                        console.error('[TimelineSettingsTab] Failed to save platform setting:', e);
                        
                        // 保存失败，恢复开关状态
                        toggle.checked = !toggle.checked;
                    }
                });
            });
        } catch (e) {
            console.error('[TimelineSettingsTab] Failed to load platform settings:', e);
        }
    }
    
    /**
     * Tab 卸载时清理
     */
    unmounted() {
        super.unmounted();
    }
}

