/**
 * 浏览器 API 兼容层
 * 
 * webextension-polyfill 创建了 `browser` 全局变量（Promise 风格）
 * 但项目代码使用的是 `chrome.*`，此文件确保 `chrome` 指向 `browser`
 * 
 * 加载顺序：browser-polyfill.js → browser-compat.js → 其他脚本
 * 
 * 环境说明：
 * - Chrome: 原生 chrome (callback)，polyfill 创建 browser (Promise)
 * - Firefox: 原生 browser (Promise)，原生 chrome (callback，兼容层)
 */
(function () {
  'use strict';
  
  // 确保 browser 存在且有效（由 webextension-polyfill 创建或 Firefox 原生）
  if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.id) {
    // 直接让 chrome 指向 browser（Promise 风格）
    // 项目只使用 storage、runtime、i18n 等通用 API，无需保留原生 chrome
    window.chrome = browser;
  }
})();

